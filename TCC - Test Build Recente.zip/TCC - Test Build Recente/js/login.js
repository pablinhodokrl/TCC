var inputlogin = document.querySelector('#login');
var inputsenha = document.querySelector('#senha');


function login(){

    let login = inputlogin.value;
    let senha = inputsenha.value;
    console.log(login);
    console.log(senha);
}


