const mod = require("./index.js");

console.log(mod.produto);




/* var mysql = require("mysql");

var conex = mysql.createConnection({ // conexão com o Banco, estabelecendo as credenciais do bd
    host: "localhost",
    user: "root",
    password: "@ra12fa34el56",
    database: "mydb"
})

conex.connect (function (err){ // TESTANDO se está conectado certin - estabelecendo a conexão com o Banco em si
    if (err){
        throw err;
    } else{
        console.log ("Server: Conectado certinho")
    }
}) */