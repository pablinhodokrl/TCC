

const teste = 'teste';

/* module.exports = {
    teste, nome
}; */

function DadosProdutos(){
    const nome = document.getElementById("nome").value;
    console.log(nome);

    const validade = document.getElementById("validade").value;
    console.log(validade);

    var produto = nome;

};

module.exports = {
    teste, nome, produto
};