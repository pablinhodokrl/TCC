<?php
// Inclui o arquivo com a função
include('valida-cnpj.php');

// Valida um CNPJ
if ( valida_cnpj('12.345.678/0001-95') ) {
    echo "CNPJ correto. <br>";
} else {
    echo "CNPJ inválido. <br>";
}
// Valida um CNPJ
if ( valida_cnpj('12.345.678/0001-93') ) {
	echo "CNPJ correto. <br>";
} else {
	echo "CNPJ inválido. <br>";
}